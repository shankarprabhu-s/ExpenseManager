package com.example.demo22;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class dashboard {
//    public void initialize() {
//        // Load the CSS file and apply it to the scene
//        Scene scene = exp.getScene();
//        scene.getStylesheets().add(getClass().getResource("/com/example/demo22/styles.css").toExternalForm());
//    }

    @FXML
    private Button accinfo;

    @FXML
    private Button bud;

    @FXML
    private Button exp;

    @FXML
    private Button inc;

    @FXML
    private Button logout;

    public void GotoExpense(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Expenses.fxml"));
            Parent expense = loader.load();

            Stage stage = (Stage) exp.getScene().getWindow();
            stage.setScene(new Scene(expense));
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that may occur during loading
        }
    }


    @FXML
    public void GotoIncome(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Incomes.fxml"));
            Parent income = loader.load();

            Stage stage = (Stage) exp.getScene().getWindow();
            stage.setScene(new Scene(income));
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that may occur during loading
        }
    }

    // Handle the "Budget" button click event
    @FXML
    public void GotoBudget(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Budget.fxml"));
            Parent budget = loader.load();

            Stage stage = (Stage) exp.getScene().getWindow();
            stage.setScene(new Scene(budget));
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that may occur during loading
        }
    }

    // Handle the "Account Info" button click event
    @FXML
    public void GotoAccInfo(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("OtherFeatures.fxml"));
            Parent accInfo = loader.load();

            Stage stage = (Stage) exp.getScene().getWindow();
            stage.setScene(new Scene(accInfo));
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that may occur during loading
        }
    }

    // Handle the "Logout" button click event
    @FXML
    public void GotoLogout(ActionEvent event) {
//        try {
//            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
//            Parent login = loader.load();
//
//            Stage stage = (Stage) exp.getScene().getWindow();
//            stage.setScene(new Scene(login));
//        } catch (Exception e) {
//            e.printStackTrace();
//            // Handle any exceptions that may occur during loading
//        }
//    }

    }
}
