package com.example.demo22;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage; // Add this import

import java.io.*;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login {
    BufferedReader br;
    PrintWriter prnt;
    ObjectInputStream obread;
    InputStream input;
    @FXML
    // fx:id="LoginPassword"
    private PasswordField LoginPassword; // Value injected by FXMLLoader

    @FXML
    private TextField loginEmail;

    @FXML
    private Button loginbtn;

    @FXML
    private Button newUser;

    @FXML
    private Label validcheck;

    private Stage primaryStage; // Create a reference to the primaryStage

    // Method to set the primaryStage
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    @FXML
    public void loginBtnClick(ActionEvent event) {
//        String username = loginEmail.getText();
//        String password = LoginPassword.getText();
//
//        if (isValidUser(username, password)) {
//            try {
//                FXMLLoader loader = new FXMLLoader(getClass().getResource("Dashboard.fxml"));
//                Parent dashboard = loader.load();
//
//                Scene currentScene = primaryStage.getScene();
//                currentScene.setRoot(dashboard);
//            } catch (Exception e) {
//                e.printStackTrace();
//                // Handle any exceptions that may occur during loading
//            }
//        } else {
//            showAlert("Login Failed", "Incorrect email or password. Please try again.");
//        }
        try {

            if (loginEmail.getText().equals("") && LoginPassword.getText().equals("")) {
                validcheck.setText("Please fill both fields");
            } else {
                //System.out.println(event);
                validcheck.setText("");
                Socket socket = new Socket("127.0.0.1", 8000); //connect here
                System.out.println("connected to server");
                //br=new BufferedReader(new InputStreamReader(socket.getInputStream())); //read form socket
                prnt=new PrintWriter(socket.getOutputStream()); //write to socket
                input=socket.getInputStream();
                obread=new ObjectInputStream(input);
                String username1=loginEmail.getText().toString();
                String pass1=LoginPassword.getText().toString();
                String fina=username1+" "+pass1;
                loginEmail.setText("");
                LoginPassword.setText("");
                prnt.println(fina);
                prnt.flush();
                String res=(String) obread.readObject();

                // System.out.println(res);
                // System.out.println(ip);
                if (res.equals("success")) {
                    try {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("dashboard.fxml"));
                        Parent dashboard = loader.load();

                        // Set the scene to the dashboard page
                        Scene currentScene = primaryStage.getScene();
                        currentScene.setRoot(dashboard);
                        primaryStage.setScene(currentScene);
                        primaryStage.show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else{
                    validcheck.setText("Invalid credentials");

                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
    }

    private boolean isValidUser(String usernameOrEmail, String password) {
        // Implement database validation logic here
        Connection connection = DatabaseConnector.establishConnection(); // Use your existing connection class to get the connection.
        try {
            String query = "SELECT * FROM user WHERE (username = ? OR email = ?) AND password = ?";            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, usernameOrEmail);
            preparedStatement.setString(2, usernameOrEmail);
            preparedStatement.setString(3, password);

            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next(); // If there's a matching user, the login is successful.
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @FXML
    void newUserReg(ActionEvent event) {
        // Add your code for handling the "New User" registration here
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("NewUser.fxml"));
            Parent newUserPage = loader.load();

            // Create a new stage for the NewUser page.
            Stage newUserStage = new Stage();
            newUserStage.setTitle("New User Registration");
            newUserStage.setScene(new Scene(newUserPage));

            // Show the new stage.
            newUserStage.show();
        } catch (Exception e) {
            e.printStackTrace();
            // Handle any exceptions that may occur during loading
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
