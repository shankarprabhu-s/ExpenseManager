/**
 * Sample Skeleton for 'OtherFeatures.fxml' Controller Class
 */

package com.example.demo22;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class OthersFeatures {

    @FXML // fx:id="Exp_down"
    private Button Exp_down; // Value injected by FXMLLoader

    @FXML // fx:id="GoBack"
    private Button GoBack; // Value injected by FXMLLoader

    @FXML // fx:id="entEmail"
    private TextField entEmail; // Value injected by FXMLLoader

    @FXML // fx:id="exp_expo"
    private Button exp_expo; // Value injected by FXMLLoader

    @FXML // fx:id="inc_down"
    private Button inc_down; // Value injected by FXMLLoader

    @FXML // fx:id="inc_expo"
    private Button inc_expo; // Value injected by FXMLLoader

    @FXML
    void downloadIncome(ActionEvent event) {

    }

    @FXML
    void enterEmailForDownload(ActionEvent event) {

    }

    @FXML
    void expenseDownload(ActionEvent event) {

    }

    @FXML
    void exportExpenses(ActionEvent event) {

    }

    @FXML
    void exportIncome(ActionEvent event) {

    }

    @FXML
    void goBackToDashboard(ActionEvent event) {
        try {
            Node source = (Node) event.getSource();

            // Get the Stage from the source Node.
            Stage stage = (Stage) source.getScene().getWindow();

            // Load the dashboard FXML file and set it as the scene.
            Parent dashboardRoot = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
            Scene dashboardScene = new Scene(dashboardRoot);

            // Set the new scene on the stage to navigate back to the dashboard.
            stage.setScene(dashboardScene);
        } catch (Exception e)
        {
            e.printStackTrace();
        }


    }

}
