package com.example.demo22;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NewUser {

    @FXML
    private TextField confPass;

    @FXML
    private TextField createPass;

    @FXML
    private TextField entEmail;

    @FXML
    private TextField entUnmae;

    @FXML
    private Button submit;

    @FXML
    void ConfirmPassword(ActionEvent event) {

    }

    @FXML
    void CreatePassword(ActionEvent event) {

    }

    @FXML
    void EnterNewEmail(ActionEvent event) {

    }

    @FXML
    void EnterUserName(ActionEvent event) {

    }

    @FXML
    void SubmitNewEmail(ActionEvent event) {
        String email = entEmail.getText();
        String password = createPass.getText();
        String username = entUnmae.getText();

        // Check if any of the fields are empty
        if (email.isEmpty() || password.isEmpty() || username.isEmpty()) {
            showAlert("Fields Empty", "All fields must be filled.");
            return;
        }

        if (!password.equals(confPass.getText())) {
            showAlert("Password Mismatch", "Password and Confirm Password do not match.");
            return;
        }

        if (saveUserDataToDatabase(email, password, username)) {
            showAlert("Registration Successful", "User registered successfully.");
        } else {
            showAlert("Registration Failed", "An error occurred during registration.");
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private boolean saveUserDataToDatabase(String email, String password, String username) {
        String url = "jdbc:mysql://localhost:3306/expensemanager";
        String user = "root";
        String pass = "shankar@2003";

        try {
            Connection connection = DriverManager.getConnection(url, user, pass);

            String checkQuery = "SELECT * FROM user WHERE email = ? OR username = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
            checkStatement.setString(1, email);
            checkStatement.setString(2, username);
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                showAlert("Account Already Exists", "An account with the same email or username already exists.");
                checkStatement.close();
                connection.close();
                return false;
            }

            String insertQuery = "INSERT INTO user (email, password, username) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, username);
            int rowsAffected = preparedStatement.executeUpdate();

            checkStatement.close();
            preparedStatement.close();
            connection.close();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
