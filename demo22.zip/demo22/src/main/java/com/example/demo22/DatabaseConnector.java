package com.example.demo22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/expensemanager";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "shankar@2003";

    public static Connection establishConnection() {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            System.out.println("Connected to the database.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    // Add other methods for executing queries, inserts, updates, etc.
}
