/**
 * Sample Skeleton for 'Expenses.fxml' Controller Class
 */

package com.example.demo22;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Expenses {

    @FXML // fx:id="GoBack"
    private Button GoBack; // Value injected by FXMLLoader

    @FXML // fx:id="SearchExp"
    private Button SearchExp; // Value injected by FXMLLoader

    @FXML // fx:id="ShowExp"
    private Button ShowExp; // Value injected by FXMLLoader

    @FXML // fx:id="addExp"
    private Button addExp; // Value injected by FXMLLoader

    @FXML // fx:id="expense_line"
    private LineChart<?, ?> expense_line; // Value injected by FXMLLoader

    @FXML // fx:id="expense_pi"
    private PieChart expense_pi; // Value injected by FXMLLoader

    @FXML
    void AddExpenses(ActionEvent event) {

    }

    @FXML
    void SearchExpenses(ActionEvent event) {

    }

    @FXML
    void ShowExpenses(ActionEvent event) {

    }

    @FXML
    void goBackToDashboard(ActionEvent event) {
        try {
            Node source = (Node) event.getSource();

            // Get the Stage from the source Node.
            Stage stage = (Stage) source.getScene().getWindow();

            // Load the dashboard FXML file and set it as the scene.
            Parent dashboardRoot = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
            Scene dashboardScene = new Scene(dashboardRoot);

            // Set the new scene on the stage to navigate back to the dashboard.
            stage.setScene(dashboardScene);
        } catch (Exception e)
        {
            e.printStackTrace();
        }

    }

}
