package com.example.demo22;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Budget {
    @FXML
    void goBackToDashboard(ActionEvent event) {
        try {
            Node source = (Node) event.getSource();

            // Get the Stage from the source Node.
            Stage stage = (Stage) source.getScene().getWindow();

            // Load the dashboard FXML file and set it as the scene.
            Parent dashboardRoot = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
            Scene dashboardScene = new Scene(dashboardRoot);

            // Set the new scene on the stage to navigate back to the dashboard.
            stage.setScene(dashboardScene);
        } catch (Exception e)
        {
            e.printStackTrace();
        }

    }
}
