/**
 * Sample Skeleton for 'Incomes.fxml' Controller Class
 */

package com.example.demo22;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Incomes {

    @FXML // fx:id="GoBack"
    private Button GoBack; // Value injected by FXMLLoader

    @FXML // fx:id="SearchInc"
    private Button SearchInc; // Value injected by FXMLLoader

    @FXML // fx:id="ShowInc"
    private Button ShowInc; // Value injected by FXMLLoader

    @FXML // fx:id="addInc"
    private Button addInc; // Value injected by FXMLLoader

    @FXML // fx:id="income_bar"
    private BarChart<?, ?> income_bar; // Value injected by FXMLLoader

    @FXML // fx:id="income_line"
    private LineChart<?, ?> income_line; // Value injected by FXMLLoader

    @FXML
    void AddIncomes(ActionEvent event) {

    }

    @FXML
    void SearchIncomes(ActionEvent event) {

    }

    @FXML
    void ShowIncomes(ActionEvent event) {

    }

    @FXML
    void goBackToDashboard(ActionEvent event) {
        try {
            Node source = (Node) event.getSource();

            // Get the Stage from the source Node.
            Stage stage = (Stage) source.getScene().getWindow();

            // Load the dashboard FXML file and set it as the scene.
            Parent dashboardRoot = FXMLLoader.load(getClass().getResource("dashboard.fxml"));
            Scene dashboardScene = new Scene(dashboardRoot);

            // Set the new scene on the stage to navigate back to the dashboard.
            stage.setScene(dashboardScene);
        } catch (Exception e)
        {
            e.printStackTrace();
        }

    }

}
